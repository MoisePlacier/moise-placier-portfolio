# Référentiel professionnel — version 0.1.0

Base factuelle et cumulative destinée à alimenter ultérieurement plusieurs variantes de CV RenderCV. **Ce dossier n’est pas un CV prêt à envoyer ni un YAML directement consommable par RenderCV.**

## Principe

- `donnees/sources.yaml` : inventaire des 12 sources, avec empreintes SHA256 lorsque le document source est disponible.
- `donnees/experiences.yaml` : 4 expériences, découpées en réalisations dotées d’IDs stables.
- `donnees/projets.yaml` : 3 projets académiques ajoutés à partir des nouveaux fichiers.
- `donnees/formations.yaml` : cursus et résultats attestés.
- `donnees/competences.yaml` : registre de compétences indexé vers les réalisations qui les illustrent.
- `donnees/a_verifier.yaml` : registre explicite des incertitudes et informations à confirmer.
- `donnees/identite.yaml` : informations génériques de profil, volontairement sans téléphone ni email.

## Discipline de preuve

La `description_factuelle` doit correspondre au texte de la source. `perimetre_ou_resultat` indique ce que les pièces rapportent, mais n’établit pas nécessairement une causalité. Le champ `statut_preuve` distingue témoignages, travaux en développement et limites méthodologiques. Les projets signés à plusieurs ne sont **pas automatiquement attribués individuellement** à Moïse.

Les chiffres (par ex. CA de 200 k€, cycles −5 à −30 %, performances ML) sont conservés avec un contexte et des réserves. Ne pas reprendre tels quels dans un CV avant validation si un point apparaît dans `a_verifier.yaml`.

## Workflow conseillé

1. Ajouter chaque nouvelle source dans `sources.yaml` en lui donnant un nouvel identifiant `S12`, `S13`, etc.
2. Pour chaque réalisation : un ID unique stable, un énoncé factuel, les résultats, les compétences correspondantes et les preuves.
3. Ajouter une question dans `a_verifier.yaml` si l’élément est ambigu (impact réel, date, contribution personnelle, métrique).
4. Ne fusionner que des doublons certains; conserver les formulations alternatives plus tard dans une couche dédiée aux CV ciblés.
5. Versionner les fichiers sous Git, puis construire à part un générateur qui transforme cette base en YAML RenderCV conforme à la version installée.

## Installation dans le projet macOS

Décompresser, puis copier `donnees/` et ce README dans `~/Code/recherche_emploi_2026/`. Cette opération est **manuelle** : le dossier de ton Mac n’est pas accessible depuis cette conversation. Conserver ton YAML RenderCV actuel tant que le futur générateur n’est pas créé.

## État de la version 0.1

- 12 sources prises en compte (11 pièces documentaires et une déclaration d’attribution du candidat)
- 4 expériences professionnelles
- 3 projets académiques
- 4 étapes de formation
- Un répertoire de compétences indexées et un registre de vérifications

**NB** : Ce référentiel est un premier dépouillement, pas encore exhaustif au regard de toutes les réalisations que tu comptes ajouter. Il pourra être enrichi sans changer les identifiants existants.
