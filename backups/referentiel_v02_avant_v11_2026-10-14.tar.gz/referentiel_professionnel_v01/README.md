# Référentiel professionnel — version 0.2.0

Base factuelle et cumulative destinée à alimenter plusieurs variantes de CV RenderCV. Ce dossier n’est pas un CV prêt à envoyer ni un YAML directement consommable par RenderCV.

## Schéma

- `donnees/identite.yaml` : identité et coordonnées.
- `donnees/experiences.yaml` : expériences, résumé neutre, réalisations, compétences démontrées et preuves.
- `donnees/projets.yaml` : projets académiques structurés sur le même principe.
- `donnees/formations.yaml` : parcours académique et résultats.
- `donnees/competences.yaml` : dictionnaire des compétences ; les relations vers les réalisations sont stockées uniquement dans les réalisations.
- `donnees/sources.yaml` : documents et preuves disponibles.
- `donnees/a_verifier.yaml` : éléments nécessitant confirmation.

Chaque expérience et projet comporte un `resume`. Chaque réalisation comporte `description_factuelle`, `perimetre_ou_resultats`, `competences` et ses preuves. Les valeurs chiffrées sont intégrées dans le périmètre ou les résultats : le champ `indicateurs` n’est plus utilisé.

## Niveaux d’affichage

Le profil cible décide du détail de chaque expérience :

1. `niveau: 1` affiche le `resume`.
2. `niveau: 2` affiche les `description_factuelle` des réalisations sélectionnées.
3. `niveau: 3` fusionne chaque `description_factuelle` avec son `perimetre_ou_resultats`.

Les règles vivent dans `profils/<profil>.yaml`; le référentiel reste indépendant du CV ciblé.

## Contrôles et génération

```bash
.venv/bin/python scripts/valider_referentiel.py
.venv/bin/python scripts/generer_cv.py --profil procedes --secteur agroalimentaire
```

Le validateur vérifie les IDs, les compétences référencées, les niveaux configurés et les champs nécessaires. Le générateur refuse de produire un CV si le référentiel est incohérent.

## Sauvegarde de migration

La version v0.1 d’origine est conservée dans `backups/referentiel_professionnel_v01_avant_v02_2026-10-14.tar.gz`.
