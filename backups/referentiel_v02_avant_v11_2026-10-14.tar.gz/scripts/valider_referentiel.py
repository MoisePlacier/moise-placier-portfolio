#!/usr/bin/env python3
"""Contrôle l'intégrité référentielle du patrimoine professionnel v0.2."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML


yaml = YAML(typ="safe")


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as file:
        return yaml.load(file)


def validate_reference(project_root: Path) -> None:
    """Lève ValueError si une relation ou un champ obligatoire est invalide."""
    data_dir = project_root / "referentiel_professionnel_v01" / "donnees"
    experiences = load_yaml(data_dir / "experiences.yaml")
    projects = load_yaml(data_dir / "projets.yaml")
    skills = load_yaml(data_dir / "competences.yaml")
    errors: list[str] = []

    for label, document in (
        ("experiences.yaml", experiences),
        ("projets.yaml", projects),
        ("competences.yaml", skills),
    ):
        if document.get("schema_version") != "0.2.0":
            errors.append(f"{label}: schema_version doit être 0.2.0.")

    skill_ids = [skill.get("id") for skill in skills.get("competences", [])]
    if len(skill_ids) != len(set(skill_ids)):
        errors.append("competences.yaml: IDs de compétences dupliqués.")
    for skill in skills.get("competences", []):
        if "realisations" in skill:
            errors.append(f"compétence {skill['id']}: relation inverse 'realisations' interdite.")
        if "niveau_de_preuve" in skill:
            errors.append(f"compétence {skill['id']}: niveau_de_preuve doit être dérivé, pas stocké.")

    for label, records in (("experiences.yaml", experiences.get("experiences", [])), ("projets.yaml", projects.get("projets", []))):
        record_ids = [record.get("id") for record in records]
        if len(record_ids) != len(set(record_ids)):
            errors.append(f"{label}: IDs de fiches dupliqués.")


    owner_by_realization: dict[str, str] = {}
    realizations_by_experience: dict[str, set[str]] = {}

    def check_records(records: list[dict[str, Any]], kind: str) -> None:
        for record in records:
            record_id = record.get("id", "<sans id>")
            if not record.get("resume"):
                errors.append(f"{kind} {record_id}: resume manquant.")
            local_ids: set[str] = set()
            for realization in record.get("realisations", []):
                realization_id = realization.get("id", "<sans id>")
                if realization_id in local_ids or realization_id in owner_by_realization:
                    errors.append(f"réalisation {realization_id}: ID dupliqué.")
                local_ids.add(realization_id)
                owner_by_realization[realization_id] = record_id
                if "indicateurs" in realization:
                    errors.append(f"réalisation {realization_id}: indicateurs doit être supprimé.")
                if "perimetre_ou_resultat" in realization:
                    errors.append(f"réalisation {realization_id}: utiliser perimetre_ou_resultats.")
                if not realization.get("description_factuelle"):
                    errors.append(f"réalisation {realization_id}: description_factuelle manquante.")
                if not realization.get("perimetre_ou_resultats"):
                    errors.append(f"réalisation {realization_id}: perimetre_ou_resultats manquant.")
                for skill_id in realization.get("competences", []):
                    if skill_id not in skill_ids:
                        errors.append(f"réalisation {realization_id}: compétence inconnue {skill_id}.")
            if kind == "expérience":
                realizations_by_experience[record_id] = local_ids

    check_records(experiences.get("experiences", []), "expérience")
    check_records(projects.get("projets", []), "projet")

    for profile_path in sorted((project_root / "profils").glob("*.yaml")):
        profile = load_yaml(profile_path)
        if "experience_rules" in profile:
            errors.append(f"{profile_path.name}: utiliser experiences au lieu de experience_rules.")
        profile_ids = [rule.get("id") for rule in profile.get("experiences", [])]
        if len(profile_ids) != len(set(profile_ids)):
            errors.append(f"{profile_path.name}: une expérience ne peut être configurée qu’une fois.")
        for rule in profile.get("experiences", []):
            experience_id = rule.get("id")
            level = rule.get("niveau")
            if experience_id not in realizations_by_experience:
                errors.append(f"{profile_path.name}: expérience inconnue {experience_id}.")
                continue
            if level not in (1, 2, 3):
                errors.append(f"{profile_path.name}: niveau invalide pour {experience_id}.")
                continue
            selected = rule.get("realisations", [])
            if level == 1 and selected:
                errors.append(f"{profile_path.name}: niveau 1 ne sélectionne pas de réalisations ({experience_id}).")
            if level in (2, 3) and not selected:
                errors.append(f"{profile_path.name}: niveau {level} doit sélectionner des réalisations ({experience_id}).")
            for realization_id in selected:
                if realization_id not in realizations_by_experience[experience_id]:
                    errors.append(
                        f"{profile_path.name}: réalisation {realization_id} absente de {experience_id}."
                    )

    if errors:
        raise ValueError("\n".join(f"- {error}" for error in errors))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--racine", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    try:
        validate_reference(args.racine.resolve())
    except ValueError as error:
        print(f"Référentiel invalide :\n{error}")
        return 1
    print("Référentiel v0.2 valide : IDs, compétences et profils cohérents.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
